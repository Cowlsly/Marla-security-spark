package com.cowlsly.securityspark

data class SecurityTip(
    val id: Int,
    val category: String,
    val text: String,
)
