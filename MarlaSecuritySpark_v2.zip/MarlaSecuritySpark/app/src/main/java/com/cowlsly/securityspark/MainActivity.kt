package com.cowlsly.securityspark

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.cowlsly.securityspark.ui.theme.BunkerCharcoal
import com.cowlsly.securityspark.ui.theme.BunkerPanel
import com.cowlsly.securityspark.ui.theme.LanternGold
import com.cowlsly.securityspark.ui.theme.LanternSoft
import com.cowlsly.securityspark.ui.theme.MutedText
import com.cowlsly.securityspark.ui.theme.SecuritySparkTheme
import com.cowlsly.securityspark.ui.theme.SparkGreen
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SecuritySparkTheme {
                SecuritySparkApp()
            }
        }
    }
}

@Composable
fun SecuritySparkApp() {
    val tips = remember { TipsRepository.tips }
    var currentTipIndex by rememberSaveable { mutableIntStateOf(0) }
    var copiedRecently by remember { mutableStateOf(false) }

    val currentTip = tips[currentTipIndex]
    val context = LocalContext.current

    Scaffold(
        containerColor = BunkerCharcoal,
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(
                    text = "🔦 Marla Security Spark",
                    style = MaterialTheme.typography.headlineMedium,
                    color = LanternSoft,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "One tap. One calm security spark. A tiny Cowlsly lantern for safer digital habits.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MutedText,
                    textAlign = TextAlign.Center,
                )

                Spacer(modifier = Modifier.height(28.dp))

                TipCard(tip = currentTip)

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        currentTipIndex = chooseDifferentTipIndex(
                            currentIndex = currentTipIndex,
                            listSize = tips.size,
                        )
                        copiedRecently = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = LanternGold,
                        contentColor = BunkerCharcoal,
                    ),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text = "Surprise Me",
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 6.dp),
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = {
                        copyTipToClipboard(
                            context = context,
                            tip = currentTip,
                        )
                        copiedRecently = true
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                ) {
                    Text(
                        text = if (copiedRecently) "Copied ✓" else "Copy Tip",
                        color = LanternSoft,
                        modifier = Modifier.padding(vertical = 4.dp),
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "No account. No ads. No network permission. Just sparks.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedText,
                    fontStyle = FontStyle.Italic,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun TipCard(tip: SecurityTip) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(
            containerColor = BunkerPanel,
            contentColor = LanternSoft,
        ),
        shape = RoundedCornerShape(28.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 8.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            modifier = Modifier.padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AssistChip(
                    onClick = { },
                    label = {
                        Text(
                            text = tip.category,
                            color = BunkerCharcoal,
                            fontWeight = FontWeight.Bold,
                        )
                    },
                    colors = androidx.compose.material3.AssistChipDefaults.assistChipColors(
                        containerColor = SparkGreen,
                        labelColor = BunkerCharcoal,
                    ),
                )

                Text(
                    text = "#${tip.id}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MutedText,
                )
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = BunkerCharcoal),
                shape = RoundedCornerShape(20.dp),
            ) {
                Text(
                    text = tip.text,
                    style = MaterialTheme.typography.titleLarge,
                    color = LanternSoft,
                    lineHeight = MaterialTheme.typography.titleLarge.lineHeight,
                    modifier = Modifier.padding(18.dp),
                )
            }
        }
    }
}

private fun chooseDifferentTipIndex(currentIndex: Int, listSize: Int): Int {
    if (listSize <= 1) return 0

    var newIndex: Int
    do {
        newIndex = Random.nextInt(listSize)
    } while (newIndex == currentIndex)

    return newIndex
}

private fun copyTipToClipboard(context: Context, tip: SecurityTip) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(
        "Marla Security Spark Tip",
        "${tip.category}: ${tip.text}",
    )

    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "Tip copied", Toast.LENGTH_SHORT).show()
}
