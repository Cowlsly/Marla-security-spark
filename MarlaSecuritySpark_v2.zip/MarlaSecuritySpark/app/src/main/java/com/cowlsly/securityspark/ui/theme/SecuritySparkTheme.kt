package com.cowlsly.securityspark.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BunkerCharcoal = Color(0xFF111815)
val BunkerPanel = Color(0xFF1C2A23)
val LanternGold = Color(0xFFF1C96B)
val LanternSoft = Color(0xFFF6E7A8)
val SparkGreen = Color(0xFF8FE3B0)
val MutedText = Color(0xFFC8D8CE)

private val SparkDarkColors = darkColorScheme(
    primary = LanternGold,
    onPrimary = BunkerCharcoal,
    secondary = SparkGreen,
    onSecondary = BunkerCharcoal,
    background = BunkerCharcoal,
    onBackground = LanternSoft,
    surface = BunkerPanel,
    onSurface = LanternSoft,
)

@Composable
fun SecuritySparkTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SparkDarkColors,
        content = content,
    )
}
