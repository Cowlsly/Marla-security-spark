package com.cowlsly.securityspark

object TipsRepository {
    val tips: List<SecurityTip> = listOf(
        SecurityTip(
            id = 1,
            category = "Password Safety",
            text = "Use a password manager so every important account can have its own long, unique password.",
        ),
        SecurityTip(
            id = 2,
            category = "Password Safety",
            text = "A passphrase can be easier to remember than a short password: four random words beats one clever-looking word.",
        ),
        SecurityTip(
            id = 3,
            category = "Password Safety",
            text = "Never reuse your email password anywhere else. If that one falls, the whole castle gate can swing open.",
        ),
        SecurityTip(
            id = 4,
            category = "Password Safety",
            text = "Change a password immediately if a service tells you there was a breach or suspicious sign-in.",
        ),
        SecurityTip(
            id = 5,
            category = "Two-Factor Authentication",
            text = "Turn on 2FA for email, banking, cloud storage, and social accounts before you worry about smaller apps.",
        ),
        SecurityTip(
            id = 6,
            category = "Two-Factor Authentication",
            text = "Authenticator apps are usually safer than SMS codes, because phone numbers can sometimes be hijacked.",
        ),
        SecurityTip(
            id = 7,
            category = "Two-Factor Authentication",
            text = "Save backup codes somewhere safe when you enable 2FA. Recovery is part of security, not an afterthought.",
        ),
        SecurityTip(
            id = 8,
            category = "Scam Avoidance",
            text = "Urgency is a scammer’s favourite perfume. Pause before clicking anything that says you must act right now.",
        ),
        SecurityTip(
            id = 9,
            category = "Scam Avoidance",
            text = "Do not trust caller ID by itself. Scammers can spoof names, numbers, and logos.",
        ),
        SecurityTip(
            id = 10,
            category = "Scam Avoidance",
            text = "If a message asks for money, gift cards, crypto, or login codes, verify through a separate trusted contact path.",
        ),
        SecurityTip(
            id = 11,
            category = "Scam Avoidance",
            text = "Hovering over links is hard on mobile, so open the official app or type the known website address yourself.",
        ),
        SecurityTip(
            id = 12,
            category = "Android Safety",
            text = "Install apps from trusted sources only, and avoid random APK mirrors unless you can verify the developer and signature.",
        ),
        SecurityTip(
            id = 13,
            category = "Android Safety",
            text = "Review app permissions after installation. A calculator should not need your contacts, microphone, and location.",
        ),
        SecurityTip(
            id = 14,
            category = "Android Safety",
            text = "Keep Android system updates and Google Play system updates current. Patch days are tiny shield-forging days.",
        ),
        SecurityTip(
            id = 15,
            category = "Android Safety",
            text = "Uninstall apps you no longer use. Old apps can become forgotten little doors in the wall.",
        ),
        SecurityTip(
            id = 16,
            category = "Android Safety",
            text = "Disable install-from-unknown-sources again after installing a trusted APK.",
        ),
        SecurityTip(
            id = 17,
            category = "Privacy",
            text = "Share less location data by setting apps to approximate location when precise location is not needed.",
        ),
        SecurityTip(
            id = 18,
            category = "Privacy",
            text = "Check which apps can access your camera, microphone, files, and notifications every month.",
        ),
        SecurityTip(
            id = 19,
            category = "Privacy",
            text = "Use separate email aliases for shopping, newsletters, and important accounts where possible.",
        ),
        SecurityTip(
            id = 20,
            category = "Privacy",
            text = "Before posting a screenshot, check for names, addresses, tabs, notifications, and account icons.",
        ),
        SecurityTip(
            id = 21,
            category = "Backups",
            text = "A backup is only real if you know how to restore it. Test recovery for your most important files.",
        ),
        SecurityTip(
            id = 22,
            category = "Backups",
            text = "Use the 3-2-1 idea: three copies, two storage types, one copy somewhere separate.",
        ),
        SecurityTip(
            id = 23,
            category = "Backups",
            text = "Do not keep your only recovery codes inside the account they are meant to recover.",
        ),
        SecurityTip(
            id = 24,
            category = "Safe Downloads",
            text = "Prefer official developer sites, F-Droid, or trusted app stores over re-upload sites with mystery APKs.",
        ),
        SecurityTip(
            id = 25,
            category = "Safe Downloads",
            text = "If a free download page has ten fake buttons, treat it like a swamp with neon arrows.",
        ),
        SecurityTip(
            id = 26,
            category = "Safe Downloads",
            text = "Check app names carefully. Copycat apps often use nearly identical names and icons.",
        ),
        SecurityTip(
            id = 27,
            category = "Tech Explanation",
            text = "An Activity is an Android screen controller. In this app, MainActivity opens the lantern and shows the Compose UI.",
        ),
        SecurityTip(
            id = 28,
            category = "Tech Explanation",
            text = "Jetpack Compose builds the screen from Kotlin functions instead of XML layouts.",
        ),
        SecurityTip(
            id = 29,
            category = "Tech Explanation",
            text = "A data class is a tidy Kotlin container for structured information, like one security tip.",
        ),
        SecurityTip(
            id = 30,
            category = "Tech Explanation",
            text = "Random selection means the app picks one item from the local tip list using Kotlin’s random function.",
        ),
        SecurityTip(
            id = 31,
            category = "Tech Explanation",
            text = "Gradle is the build system. It gathers code, resources, and dependencies, then cooks them into an APK.",
        ),
        SecurityTip(
            id = 32,
            category = "Tech Explanation",
            text = "GitHub Actions can build the APK in the cloud, which means your Fold 6 can steer the project without being the workshop furnace.",
        ),
        SecurityTip(
            id = 33,
            category = "Spy History",
            text = "During World War II, codebreakers relied on careful routines as much as clever machines. Process matters.",
        ),
        SecurityTip(
            id = 34,
            category = "Spy History",
            text = "Invisible ink is old spycraft, but modern privacy often comes from plain habits: updates, backups, and good passwords.",
        ),
        SecurityTip(
            id = 35,
            category = "Spy History",
            text = "The best secret messages are useless if the courier is careless. In tech, your habits are the courier.",
        ),
        SecurityTip(
            id = 36,
            category = "Calm Security",
            text = "Security is not about panic. It is about reducing easy risks one small step at a time.",
        ),
        SecurityTip(
            id = 37,
            category = "Calm Security",
            text = "If something feels wrong online, stop, breathe, and verify. Calm is a security tool.",
        ),
        SecurityTip(
            id = 38,
            category = "Calm Security",
            text = "The strongest digital bunker is built from boring habits repeated consistently.",
        )
    )
}
