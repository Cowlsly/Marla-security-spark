# Empty for now. This starter app does not need custom shrinking rules.
